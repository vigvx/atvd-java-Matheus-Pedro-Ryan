/**
 * Classe Caminhao — implementa (herda) Automovel.
 * Relacionamento: Caminhao <<implementa>> Automovel
 */
public class Caminhao extends Automovel {

    private double capacidadeCarga; // toneladas — atributo específico de Caminhao

    public Caminhao(String marca, String modelo, int ano, double preco, double capacidadeCarga) {
        super(marca, modelo, ano, preco);
        this.capacidadeCarga = capacidadeCarga;
    }

    /**
     * POLIMORFISMO: implementação do método abstrato com retorno diferente do Carro.
     */
    @Override
    public String getTipoVeiculo() {
        return "Caminhão";
    }

    @Override
    public String getDescricao() {
        return super.getDescricao() + " | Carga: " + capacidadeCarga + "t";
    }

    public double getCapacidadeCarga() { return capacidadeCarga; }
    public void setCapacidadeCarga(double capacidadeCarga) { this.capacidadeCarga = capacidadeCarga; }
}
