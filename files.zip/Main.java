/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║           SISTEMA DE VENDA DE VEÍCULOS — Main               ║
 * ║                                                              ║
 * ║  Demonstra:                                                  ║
 * ║  • Herança (Pessoa → Cliente / Vendedor)                     ║
 * ║  • Classe Abstrata (Automovel → Carro / Caminhao)            ║
 * ║  • Polimorfismo (listas e chamadas de métodos)               ║
 * ║  • Encapsulamento (private + getters/setters)                ║
 * ║  • Casos de uso do diagrama UML                              ║
 * ╚══════════════════════════════════════════════════════════════╝
 */
public class Main {

    public static void main(String[] args) {

        System.out.println("╔══════════════════════════════════════╗");
        System.out.println("║   SISTEMA DE VENDA DE VEÍCULOS       ║");
        System.out.println("╚══════════════════════════════════════╝\n");

        SistemaVendas sistema = new SistemaVendas();

        // ─── 1. Criar e cadastrar VENDEDOR ───────────────────────────────────
        System.out.println("── CADASTRANDO VENDEDORES ──");
        Vendedor vendedor = new Vendedor(1, "Carlos Oliveira");
        sistema.adicionarVendedor(vendedor);

        // ─── 2. Criar e cadastrar CLIENTE ────────────────────────────────────
        System.out.println("\n── CADASTRANDO CLIENTES ──");
        Cliente cliente1 = new Cliente(101, "Ana Souza");
        Cliente cliente2 = new Cliente(102, "Bruno Lima");
        sistema.adicionarCliente(cliente1);
        sistema.adicionarCliente(cliente2);

        // ─── 3. Criar e cadastrar CARRO ──────────────────────────────────────
        System.out.println("\n── CADASTRANDO VEÍCULOS ──");
        Carro carro = new Carro("Toyota", "Corolla", 2023, 115000.00, 4);
        sistema.adicionarVeiculo(carro);

        // ─── 4. Criar e cadastrar CAMINHÃO ───────────────────────────────────
        Caminhao caminhao = new Caminhao("Volvo", "FH 540", 2022, 680000.00, 25.0);
        sistema.adicionarVeiculo(caminhao);

        // Listagem de veículos — POLIMORFISMO em ação
        sistema.listarVeiculos();

        // ─── 5. REALIZAR VENDAS ──────────────────────────────────────────────
        System.out.println("\n── REALIZANDO VENDAS ──");

        // Venda 1: Ana compra 1 Carro
        Venda venda1 = sistema.realizarVenda(cliente1, carro, vendedor, 1, 115000.00);

        // Venda 2: Bruno compra 2 Caminhões
        Venda venda2 = sistema.realizarVenda(cliente2, caminhao, vendedor, 2, 680000.00);

        // ─── 6. Listar clientes ───────────────────────────────────────────────
        sistema.listarClientes();

        // ─── 7. Histórico de vendas ───────────────────────────────────────────
        sistema.listarVendas();

        // ─── 8. Relatório final ───────────────────────────────────────────────
        System.out.println("── RELATÓRIO FINAL ──");
        System.out.printf("  Total vendido: R$ %.2f%n", sistema.getTotalVendido());

        // ─── 9. Demonstração de POLIMORFISMO explícito ───────────────────────
        System.out.println("\n── POLIMORFISMO EM AÇÃO ──");
        Automovel[] veiculos = { carro, caminhao };
        for (Automovel v : veiculos) {
            // getTipoVeiculo() resolve em tempo de execução para "Carro" ou "Caminhão"
            System.out.println("  Tipo (polimórfico): " + v.getTipoVeiculo());
            System.out.println("  Descrição         : " + v.getDescricao());
            System.out.println();
        }

        // ─── 10. Demonstração de ENCAPSULAMENTO ──────────────────────────────
        System.out.println("── ENCAPSULAMENTO ──");
        System.out.println("  Nome do cliente via getter: " + cliente1.getNome());
        cliente1.setNome("Ana Paula Souza"); // setter alterando o estado
        System.out.println("  Nome atualizado via setter: " + cliente1.getNome());
    }
}
