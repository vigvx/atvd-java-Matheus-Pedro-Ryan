/**
 * Classe abstrata Automovel.
 * 
 * DECISÃO: Usamos classe abstrata (abstract class) em vez de interface porque:
 * - Automóvel tem atributos de estado concretos (marca, modelo, preco)
 * - Fornece implementação parcial compartilhada pelas subclasses
 * - Interfaces em Java não podem ter atributos de instância com estado
 * - Representa uma entidade incompleta (nenhum objeto é "apenas um automóvel")
 */
public abstract class Automovel {

    // Atributos encapsulados (private)
    private String marca;
    private String modelo;
    private int ano;
    private double preco;

    // Construtor
    public Automovel(String marca, String modelo, int ano, double preco) {
        this.marca = marca;
        this.modelo = modelo;
        this.ano = ano;
        this.preco = preco;
    }

    /**
     * Método abstrato: força cada subclasse a descrever seu tipo.
     * Isso é POLIMORFISMO — cada subclasse implementa de forma diferente.
     */
    public abstract String getTipoVeiculo();

    /**
     * Método concreto compartilhado por todas as subclasses.
     * Polimorfismo de sobrescrita (override) é possível nas subclasses.
     */
    public String getDescricao() {
        return getTipoVeiculo() + ": " + marca + " " + modelo + " (" + ano + ") - R$ " + String.format("%.2f", preco);
    }

    // Getters e Setters
    public String getMarca() { return marca; }
    public void setMarca(String marca) { this.marca = marca; }

    public String getModelo() { return modelo; }
    public void setModelo(String modelo) { this.modelo = modelo; }

    public int getAno() { return ano; }
    public void setAno(int ano) { this.ano = ano; }

    public double getPreco() { return preco; }
    public void setPreco(double preco) { this.preco = preco; }

    @Override
    public String toString() {
        return getDescricao();
    }
}
