// ═══════════════════════════════════════════════════════════════════════════
//   SISTEMA DE VENDA DE VEÍCULOS — Código Completo
//   Baseado no diagrama UML (quadro branco)
//   Compilar: javac *.java   |   Executar: java Main
// ═══════════════════════════════════════════════════════════════════════════

// ─── Arquivo: Pessoa.java ────────────────────────────────────────────────
/*
public abstract class Pessoa {
    private String nome;
    public Pessoa(String nome) { this.nome = nome; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    @Override public String toString() { return nome; }
}
*/

// ─── Arquivo: Cliente.java ───────────────────────────────────────────────
/*
public class Cliente extends Pessoa {
    private int codigo;
    public Cliente(int codigo, String nome) { super(nome); this.codigo = codigo; }
    public int getCodigo() { return codigo; }
    public void setCodigo(int codigo) { this.codigo = codigo; }
    @Override public String toString() { return "Cliente[" + codigo + "] " + getNome(); }
}
*/

// ─── Arquivo: Vendedor.java ──────────────────────────────────────────────
/*
public class Vendedor extends Pessoa {
    private int codigo;
    public Vendedor(int codigo, String nome) { super(nome); this.codigo = codigo; }
    public int getCodigo() { return codigo; }
    public void setCodigo(int codigo) { this.codigo = codigo; }
    @Override public String toString() { return "Vendedor[" + codigo + "] " + getNome(); }
}
*/

// ─── Arquivo: Automovel.java ─────────────────────────────────────────────
/*
public abstract class Automovel {
    private String marca, modelo;
    private int ano;
    private double preco;
    public Automovel(String marca, String modelo, int ano, double preco) {
        this.marca = marca; this.modelo = modelo; this.ano = ano; this.preco = preco;
    }
    public abstract String getTipoVeiculo();
    public String getDescricao() {
        return getTipoVeiculo() + ": " + marca + " " + modelo + " (" + ano + ") - R$ " + String.format("%.2f", preco);
    }
    public String getMarca() { return marca; } public void setMarca(String m) { marca = m; }
    public String getModelo() { return modelo; } public void setModelo(String m) { modelo = m; }
    public int getAno() { return ano; } public void setAno(int a) { ano = a; }
    public double getPreco() { return preco; } public void setPreco(double p) { preco = p; }
    @Override public String toString() { return getDescricao(); }
}
*/

// ─── Arquivo: Carro.java ─────────────────────────────────────────────────
/*
public class Carro extends Automovel {
    private int numeroDePortas;
    public Carro(String marca, String modelo, int ano, double preco, int portas) {
        super(marca, modelo, ano, preco); this.numeroDePortas = portas;
    }
    @Override public String getTipoVeiculo() { return "Carro"; }
    @Override public String getDescricao() { return super.getDescricao() + " | Portas: " + numeroDePortas; }
    public int getNumeroDePortas() { return numeroDePortas; }
    public void setNumeroDePortas(int p) { numeroDePortas = p; }
}
*/

// ─── Arquivo: Caminhao.java ──────────────────────────────────────────────
/*
public class Caminhao extends Automovel {
    private double capacidadeCarga;
    public Caminhao(String marca, String modelo, int ano, double preco, double capacidadeCarga) {
        super(marca, modelo, ano, preco); this.capacidadeCarga = capacidadeCarga;
    }
    @Override public String getTipoVeiculo() { return "Caminhão"; }
    @Override public String getDescricao() { return super.getDescricao() + " | Carga: " + capacidadeCarga + "t"; }
    public double getCapacidadeCarga() { return capacidadeCarga; }
    public void setCapacidadeCarga(double c) { capacidadeCarga = c; }
}
*/

// ─── Arquivo: Venda.java ─────────────────────────────────────────────────
/*
public class Venda {
    private static int contadorId = 1;
    private int id;
    private Cliente cliente;
    private Automovel automovel;
    private Vendedor vendedor;
    private int qtd;
    private double preco;

    public Venda(Cliente cliente, Automovel automovel, Vendedor vendedor, int qtd, double preco) {
        this.id = contadorId++; this.cliente = cliente; this.automovel = automovel;
        this.vendedor = vendedor; this.qtd = qtd; this.preco = preco;
    }
    public double getValorTotal() { return qtd * preco; }
    public int getId() { return id; }
    public Cliente getCliente() { return cliente; } public void setCliente(Cliente c) { cliente = c; }
    public Automovel getAutomovel() { return automovel; } public void setAutomovel(Automovel a) { automovel = a; }
    public Vendedor getVendedor() { return vendedor; } public void setVendedor(Vendedor v) { vendedor = v; }
    public int getQtd() { return qtd; } public void setQtd(int q) { qtd = q; }
    public double getPreco() { return preco; } public void setPreco(double p) { preco = p; }
    @Override public String toString() {
        return "=== VENDA #" + id + " ===\n" +
               "  Cliente   : " + cliente + "\n" +
               "  Vendedor  : " + vendedor + "\n" +
               "  Veículo   : " + automovel.getDescricao() + "\n" +
               "  Quantidade: " + qtd + "\n" +
               "  Preço unit: R$ " + String.format("%.2f", preco) + "\n" +
               "  TOTAL     : R$ " + String.format("%.2f", getValorTotal());
    }
}
*/

// ─── Arquivo: SistemaVendas.java ─────────────────────────────────────────
// Omitido no resumo — ver arquivo separado

// ─── DIAGRAMA UML TEXTUAL ─────────────────────────────────────────────────
/*
┌─────────────────────────────────────────────────────────────────┐
│                    SISTEMA DE VENDA DE CARROS                   │
└─────────────────────────────────────────────────────────────────┘

         ┌──────────────────┐
         │   <<abstract>>   │
         │     Pessoa       │
         │──────────────────│
         │ - nome: String   │
         │──────────────────│
         │ + getNome()      │
         │ + setNome()      │
         └────────┬─────────┘
                  │  <<herança>>
          ┌───────┴───────┐
          │               │
   ┌──────▼──────┐  ┌─────▼──────┐
   │   Cliente   │  │  Vendedor  │
   │─────────────│  │────────────│
   │-codigo: int │  │-codigo:int │
   │─────────────│  │────────────│
   │+getCodigo() │  │+getCodigo()│
   └─────────────┘  └────────────┘

         ┌──────────────────┐
         │   <<abstract>>   │
         │    Automovel     │
         │──────────────────│
         │ - marca: String  │
         │ - modelo: String │
         │ - ano: int       │
         │ - preco: double  │
         │──────────────────│
         │+getTipoVeiculo() │◄── método abstrato
         │+getDescricao()   │
         └────────┬─────────┘
                  │  <<herança>>
          ┌───────┴───────┐
          │               │
   ┌──────▼──────┐  ┌─────▼──────────┐
   │    Carro    │  │    Caminhao    │
   │─────────────│  │────────────────│
   │-numPortas   │  │-capacidade     │
   │─────────────│  │────────────────│
   │+getTipo()   │  │+getTipo()      │
   └─────────────┘  └────────────────┘

         ┌─────────────────────────┐
         │          Venda          │
         │─────────────────────────│
         │ - id: int               │
         │ - cliente: Cliente      │──────► <<depende>> Cliente
         │ - automovel: Automovel  │──────► <<depende>> Automovel
         │ - vendedor: Vendedor    │
         │ - qtd: int              │
         │ - preco: double         │
         │─────────────────────────│
         │ + getValorTotal()       │
         └─────────────────────────┘

CASOS DE USO:
  [Usuário] ──► (Realizar Venda)
  [Usuário] ──► (Manter Clientes)
  [Usuário] ──► (Manter Produtos/Veículos)
*/

public class SistemaVeiculosCompleto {
    // Este arquivo existe apenas como referência textual.
    // Execute os arquivos separados para rodar o sistema.
}
