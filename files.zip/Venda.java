/**
 * Classe Venda.
 * 
 * RELACIONAMENTO (conforme diagrama):
 * - Venda <<depende>> Cliente     → usa um objeto Cliente
 * - Venda <<depende>> Automovel   → usa um objeto Automovel (polimórfico!)
 * 
 * Dependência significa que Venda usa esses objetos, mas não os cria.
 * Os objetos são passados de fora (injeção via construtor).
 * 
 * Atributos conforme diagrama:
 *   cliente:   Cliente
 *   automovel: Automovel
 *   qtd:       int
 *   preco:     double
 */
public class Venda {

    private static int contadorId = 1; // gerador automático de ID

    private int id;
    private Cliente cliente;
    private Automovel automovel;  // POLIMORFISMO: pode ser Carro ou Caminhao
    private Vendedor vendedor;
    private int qtd;
    private double preco;

    public Venda(Cliente cliente, Automovel automovel, Vendedor vendedor, int qtd, double preco) {
        this.id = contadorId++;
        this.cliente = cliente;
        this.automovel = automovel;
        this.vendedor = vendedor;
        this.qtd = qtd;
        this.preco = preco;
    }

    /**
     * Calcula o valor total da venda.
     */
    public double getValorTotal() {
        return qtd * preco;
    }

    // Getters e Setters — ENCAPSULAMENTO
    public int getId() { return id; }

    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }

    public Automovel getAutomovel() { return automovel; }
    public void setAutomovel(Automovel automovel) { this.automovel = automovel; }

    public Vendedor getVendedor() { return vendedor; }
    public void setVendedor(Vendedor vendedor) { this.vendedor = vendedor; }

    public int getQtd() { return qtd; }
    public void setQtd(int qtd) { this.qtd = qtd; }

    public double getPreco() { return preco; }
    public void setPreco(double preco) { this.preco = preco; }

    @Override
    public String toString() {
        return "=== VENDA #" + id + " ===\n" +
               "  Cliente   : " + cliente + "\n" +
               "  Vendedor  : " + vendedor + "\n" +
               "  Veículo   : " + automovel.getDescricao() + "\n" +
               "  Quantidade: " + qtd + "\n" +
               "  Preço unit: R$ " + String.format("%.2f", preco) + "\n" +
               "  TOTAL     : R$ " + String.format("%.2f", getValorTotal());
    }
}
