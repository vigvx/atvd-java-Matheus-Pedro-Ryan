/**
 * Classe abstrata Pessoa.
 * 
 * DECISÃO: Abstrata porque nenhum objeto deve ser criado como "apenas uma Pessoa".
 * Toda pessoa no sistema é ou Cliente ou Vendedor.
 * 
 * Relacionamento:
 * - Cliente <<herda>> Pessoa
 * - Vendedor <<herda>> Pessoa
 */
public abstract class Pessoa {

    private String nome; // atributo do diagrama: nome: String

    public Pessoa(String nome) {
        this.nome = nome;
    }

    // Getter e Setter — ENCAPSULAMENTO
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    @Override
    public String toString() {
        return nome;
    }
}
