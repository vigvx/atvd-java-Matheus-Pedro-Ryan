/**
 * Classe Carro — implementa (herda) Automovel.
 * Relacionamento: Carro <<implementa>> Automovel
 */
public class Carro extends Automovel {

    private int numeroDePorras; // atributo específico de Carro

    public Carro(String marca, String modelo, int ano, double preco, int numeroDePortas) {
        super(marca, modelo, ano, preco); // chama construtor da classe abstrata
        this.numeroDePorras = numeroDePortas;
    }

    /**
     * POLIMORFISMO: implementação obrigatória do método abstrato.
     */
    @Override
    public String getTipoVeiculo() {
        return "Carro";
    }

    @Override
    public String getDescricao() {
        return super.getDescricao() + " | Portas: " + numeroDePorras;
    }

    public int getNumeroDePortas() { return numeroDePorras; }
    public void setNumeroDePortas(int numeroDePortas) { this.numeroDePorras = numeroDePortas; }
}
